package edu.iut.demo_json;

import java.util.Map;


/**
 * Modify by Fred on 05/03/2025.
 */
public class ValorantCharacter {

    private final String TAG = "fred "+getClass().getSimpleName();
    private int id;
    private Map<String, String> name; //depends of settings language
    private Map<String, String>  description;  //depends of settings language
    private Map<String, Integer>  skills;  //depends of settings language
    private float value;
    private String pictureFace;
    private String pictureFull;



    public ValorantCharacter() {
        super();
    }

    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }


    public String getName() {
        return name.get(Settings.language);
    }

    public void setName(Map<String, String> name) {
        this.name = name;
    }

    public String getDescription() {
        return description.get(Settings.language);
    }
    public void setDescription(Map<String, String> description) {
        this.description = description;
    }


    /* public String getSkills() {
        return description.get(Settings.language);
    }

     */
    public int getUtility(){
        return skills.get("utility");
    }

    public int getCrowdControl(){
        return skills.get("crowdControl");
    }

    public int getDamage(){
        return skills.get("damage");
    }


    public void setSkills(Map<String, Integer> skills) {
        this.skills = skills;
    }

    public float getValue() {
        return value;
    }
    public void setValue(float value) {
        this.value = value;
    }

    public String getPictureFace() {
        return pictureFace;
    }
    public void setPictureFace(String pictureFace) {
        this.pictureFace = "http://edu.info06.net/valorant"
                + "/pictures_faces/"
                + pictureFace;
    }

    public String getPictureFull() {
        return pictureFull;
    }
    public void setPictureFull(String pictureFull) {
        this.pictureFull = pictureFull;
    }

    @Override
    public String toString(){
        return getName() + "(" +  getValue() +  ")";
    }


}