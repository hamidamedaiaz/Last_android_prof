package edu.iut.demo_json;

public class Settings {
    public static String language;
}
