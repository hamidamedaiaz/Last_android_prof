package edu.iut.demo_json;

import android.app.ProgressDialog;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.util.Log;
import android.widget.ListView;
import android.widget.SeekBar;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import com.squareup.picasso.Picasso;
import com.squareup.picasso.Target;

import java.util.ArrayList;
import java.util.List;

/**
 * Demonstration how to use HttpAsyncGet for Pokemon json file from web
 * Then use PICASO lib: to display picture from URL reference
 *  -Gradle script: --> implementation 'com.squareup.picasso:picasso:2.71828'
 *
 * @author Frédéric RALLO - feb 2024
 */


public class MainActivity extends AppCompatActivity implements PostExecuteActivity<ValorantCharacter>, Clickable {
    private final String TAG = "fred "+getClass().getSimpleName();
    private static final List<ValorantCharacter> VALORANT_CHARACTERS = new ArrayList<>(); //the complete list
    private final List<ValorantCharacter> displayedValorantCharacters = new ArrayList<>(); //the displayed list
    private  CharacterAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Settings.language = getString(R.string.language);
        String url = "http://edu.info06.net/valorant/characters.json";
        //todo: try to change context from MainActivity.this in getApplicationContext()
        new HttpAsyncGet<>(url, ValorantCharacter.class, this, new ProgressDialog(MainActivity.this) );
        SeekBar seekBar = findViewById(R.id.seekBar);
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int seekBarValue, boolean b) {
                Log.d(TAG, "onProgressChanged = " + seekBarValue);
                ((TextView)findViewById(R.id.value)).setText(""+seekBarValue);
                displayedValorantCharacters.clear();
                for(ValorantCharacter valorantCharacter : VALORANT_CHARACTERS) {
                    if(valorantCharacter.getValue() >= seekBarValue) displayedValorantCharacters.add(valorantCharacter);
                }
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

    }


    /**
     * asynchrone callBack task
     * this is HttpAsyncGet instance is ready
     * @param itemList is the return item from webService
     */
    public void onPostExecute(List<ValorantCharacter> itemList) {
        VALORANT_CHARACTERS.addAll(itemList);
        displayedValorantCharacters.addAll(itemList);
        //Création et initialisation de l'Adapter pour les pizzas (+ abonnement listener pour lorsqu'on cliquera)
        adapter = new CharacterAdapter(displayedValorantCharacters, this);

        //Initialisation de la liste avec les données
        ListView listview = findViewById(R.id.listView);
        listview.setAdapter(adapter);
        Log.d(TAG,"itemList = " + itemList);
    }


    @Override
    public void onClicItem(int itemIndex) {
        Log.d(TAG, "clicked on = " + VALORANT_CHARACTERS.get(itemIndex).getName());
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);

        // set title
        alertDialogBuilder.setTitle(VALORANT_CHARACTERS.get(itemIndex).getName());
        Picasso.get().load(VALORANT_CHARACTERS.get(itemIndex).getPictureFace()).into(new Target() {
            @Override
            public void onBitmapLoaded(Bitmap bitmap, Picasso.LoadedFrom from) {
                // Convertir le Bitmap en Drawable
                Drawable drawable = new BitmapDrawable(getResources(), bitmap);

                // Définir l'icône de l'AlertDialog avec le Drawable chargé
                alertDialogBuilder.setIcon(drawable);
            }

            @Override
            public void onBitmapFailed(Exception e, Drawable errorDrawable) {
                // Gérer l'échec du chargement de l'image
                // Vous pouvez afficher un Drawable de remplacement ou afficher un message d'erreur
            }

            @Override
            public void onPrepareLoad(Drawable placeHolderDrawable) {
                // Optionnel : vous pouvez effectuer des actions de préparation avant le chargement de l'image
            }
        });

        // set dialog message
        alertDialogBuilder.setMessage( VALORANT_CHARACTERS.get(itemIndex).getDescription())
                .setCancelable(false)
                .setNeutralButton("Ok",null);

        // create alert dialog
        AlertDialog alertDialog = alertDialogBuilder.create();

        // show it
        alertDialog.show();

    }


    @Override
    public void onRatingBarChange(int itemIndex, float value) {
        Log.d(TAG, VALORANT_CHARACTERS.get(itemIndex).getName()+" old value = " + VALORANT_CHARACTERS.get(itemIndex).getValue() +  " new value = " + value);
        VALORANT_CHARACTERS.get(itemIndex).setValue(value);
        displayedValorantCharacters.get(itemIndex).setValue(value);
        adapter.notifyDataSetChanged();
    }

    @Override
    public Context getContext() {
        return getApplicationContext();
    }
}